const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1'
};

export default CONFIG;